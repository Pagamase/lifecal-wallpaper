# Parche: GUI guarda JSON sin BOM (arregla build en Vercel)

## Problema
Después de "Editar estilo" + Push desde la GUI, Vercel falla con:
- invalid JSON / expected value at line 1 column 1
y en el snippet aparece un carácter raro antes de `{`.

Esto suele pasar porque PowerShell 5.1 escribe UTF-8 **con BOM** por defecto, y el loader de JSON en Next/Vercel puede no aceptarlo.

## Qué hace este parche
- Sustituye `select-route-gui.ps1` para que escriba JSON en **UTF-8 sin BOM**.
- Incluye `app/year/style.json` válido para resetear el archivo roto.
- Incluye `lifecal_route_backups/style.json` para que TypeScript no falle al compilar backups.

## Cómo aplicar (sin ensuciar)
1) Copia y sobrescribe en la RAÍZ del repo:
   - select-route-gui.ps1
   - (opcional) select-route-gui.cmd
2) Sobrescribe:
   - app/year/style.json
   - lifecal_route_backups/style.json
3) Commit + push.

Después ya puedes volver a editar estilo desde la GUI sin romper Vercel.
